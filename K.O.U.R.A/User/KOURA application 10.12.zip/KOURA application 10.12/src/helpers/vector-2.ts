import { action, computed, observable } from "mobx";

export class Vector2 {
    @observable public x : number;
    @observable public y : number;

    constructor(x: number = 0, y: number = 0) {
        this.x = x;
        this.y = y;
    }

    @computed
    public get magnitude(): number {
        return Math.sqrt(this.x * this.x + this.y * this.y);
    }

    @action
    public normalize(): void {
        if(Math.abs(this.magnitude) < 0.01) return;
        let magnitude = this.magnitude;
        this.x /= magnitude;
        this.y /= magnitude;
    }

    @action
    public json() {
        return [this.x,this.y];
    }

    public setX(x: number): void {
        this.x = x;
    }

    public setY(y: number): void {
        this.y = y;
    }

}