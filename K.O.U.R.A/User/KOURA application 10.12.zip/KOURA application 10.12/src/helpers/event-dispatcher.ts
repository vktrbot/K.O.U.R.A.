export class Listener<T> {
    private _callback: (content: T) => void;
    private _id: string;

    constructor(callback: (content: T) => void, id: string = "") {
        if(id === "") {
            id = Date.now().toString();
        }
        this._callback = callback;
        this._id = id;
    }

    public get id() {
        return this._id;
    }

    public dispatch(content: T) {
        this._callback(content);
    }
}

export class EventDispatcher<T> {
    private _listeners: Listener<T>[];

    constructor() {
        this._listeners = [];
    }
    
    public registerListener(callback: (content: T) => void): string {
        const listener = new Listener<T>(callback);
        this._listeners.push(listener);
        return listener.id;
    }

    public unregisterListener(id: string) {
        this._listeners = this._listeners.filter(listener => listener.id !== id);
    }

    public raise(content: T) {
        for(let listener of this._listeners) {
            listener.dispatch(content);
        }
    }
}