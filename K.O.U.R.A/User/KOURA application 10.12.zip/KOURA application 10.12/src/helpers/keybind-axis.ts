import IKeybindAxis from "@/interfaces/common/i-keybind-axis";
import { observable } from "mobx";

export default class KeyBindAxis implements IKeybindAxis {

    @observable private _positiveKey: string;
    @observable private _negativeKey: string;
    @observable private _responsiveness: number;
    
    public get positiveKey() {
        return this._positiveKey;
    }
    public get negativeKey() {
        return this._negativeKey;
    }
    public get responsiveness() {
        return this._responsiveness;
    }

    constructor(positiveKey: string, negativeKey: string, responsiveness: number = 12) {
        this._positiveKey = positiveKey;
        this._negativeKey = negativeKey;
        this._responsiveness = responsiveness;
    }
    setPositiveKey(key: string) {
        this._positiveKey = this.positiveKey;
    }
    setNegativeKey(negativeKey: string) {
        this._negativeKey = negativeKey;
    }
}