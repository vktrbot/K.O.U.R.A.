/// <reference types="vite/client" />
interface ImportMetaEnv {
    readonly VITE_CONTROL_MODE_FEATURE_ENABLED: string;
}

interface ImportMeta {
    readonly env: ImportMetaEnv;
}