import IKeybindAxis from "@/interfaces/common/i-keybind-axis";
import keyboardjs from "keyboardjs";
import { useEffect, useRef, useState } from "react";

export const useKeybindAxis = (axis: IKeybindAxis): [number, boolean, boolean] => {
    const [value, setValue] = useState(0);
    const target = useRef(0);
    const isPositiveReference = useRef(false);
    const isNegativeReference = useRef(false);

    useEffect(() => {
        const updateState = () => {
            let newTarget = 0;
            if(isNegativeReference.current) newTarget -= 1;
            if(isPositiveReference.current) newTarget += 1;

            target.current = newTarget;
        }

        const disableNegativeKey = () => {
            isNegativeReference.current = false;
            updateState();
        }

        const enableNegativeKey = () => {
            isNegativeReference.current = true;
            updateState();
        }

        const enablePositiveKey = () => {
            isPositiveReference.current = true;
            updateState();
        }

        const disablePositiveKey = () => {
            isPositiveReference.current = false;
            updateState();
        }

        keyboardjs.bind(axis.negativeKey, enableNegativeKey, disableNegativeKey);
        keyboardjs.bind(axis.positiveKey, enablePositiveKey, disablePositiveKey);
        
        let frameId: number;
        let lastTime = performance.now(); // getting current time in miliseconds

        const onNewFrameUpdate = (time: number) => {
            const delta = (time - lastTime) / 1000;
            lastTime = time;
            setValue(prev => {
                const reference = target.current;
                if(prev === reference) return prev;
                const step = Math.min(1, delta * axis.responsiveness);
                const valueToSet = prev + (reference - prev) * step;

                if(Math.abs(valueToSet - reference) < 0.001) return reference;
                return valueToSet;
            });
            frameId = requestAnimationFrame(onNewFrameUpdate);
        }

        frameId = requestAnimationFrame(onNewFrameUpdate);

        return () => {
            keyboardjs.unbind(axis.negativeKey, enableNegativeKey, disableNegativeKey);
            keyboardjs.unbind(axis.positiveKey, enablePositiveKey, disablePositiveKey);
        };
    }, []);

    return [value, isPositiveReference.current, isNegativeReference.current];
}