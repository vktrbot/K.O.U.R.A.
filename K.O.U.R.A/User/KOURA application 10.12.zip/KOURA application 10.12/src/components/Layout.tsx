import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Gamepad2,
  Wifi,
  Signal
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Ohjaus",
    url: "/",
    icon: Gamepad2,
  },
  {
    title: "Yhteys",
    url: "/connection",
    icon: Wifi,
  },
];

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50 text-gray-900">
        <Sidebar className="border-r border-purple-200 bg-white/95 backdrop-blur-xl w-64 shadow-lg">
          <SidebarHeader className="border-b border-purple-100 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-violet-600 rounded-lg flex items-center justify-center shadow-lg">
                <Gamepad2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-xl text-gray-900 tracking-wider">K.O.U.R.A</h2>
                <p className="text-xs text-purple-600 font-medium">Teleoperation Platform</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs uppercase tracking-wider text-purple-600 font-bold mb-2">
                Navigaatio
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        isActive={location.pathname === item.url}
                        className="data-[active=true]:bg-purple-100 data-[active=true]:text-purple-700 hover:bg-purple-50 rounded-lg transition-all"
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-semibold">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-purple-100 p-4">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Signal className="w-4 h-4 text-purple-500" />
              <span className="font-medium">Versio 1.0.0</span>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 overflow-auto">
          <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-purple-100 px-6 py-4 flex items-center gap-4 shadow-sm">
            <SidebarTrigger className="lg:hidden text-purple-600" />
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
              <h1 className="text-xl font-bold text-gray-900">K.O.U.R.A Teleoperation</h1>
            </div>
          </div>
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
