import IConnectionProfile from "@/interfaces/common/i-connection-profile";
import { makeAutoObservable } from "mobx";

export default class ConnectionProfile implements IConnectionProfile {
    id: string;
    name: string;
    connection_type: string;
    host: string;
    port: number;
    auth_token?: string;
    is_active: boolean;

    constructor(id: string, name: string, connection_type: string, host: string, port: number, auth_token: string | undefined = undefined) {
        this.id = id;
        this.name = name;
        this.connection_type = connection_type;
        this.host = host;
        this.port = port;
        this.auth_token = auth_token;
        this.is_active = false;
        makeAutoObservable(this);
    }

    public setActive(state: boolean) {
        this.is_active = state;
    }
}